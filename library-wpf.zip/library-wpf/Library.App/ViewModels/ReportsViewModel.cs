using System.Collections.ObjectModel;
using Library.App.Infrastructure;
using Library.App.Models;
using Library.App.Services;

namespace Library.App.ViewModels;

/// <summary>Экран отчётов: четыре LINQ-отчёта и выгрузка в JSON с настраиваемой структурой.</summary>
public sealed class ReportsViewModel : ViewModelBase
{
    private readonly LibraryWorkspace _workspace;
    private readonly ReportService _reportService;
    private readonly IReportExporter _exporter;
    private readonly IDialogService _dialogs;
    private readonly ApplicationState _state;

    private LibraryReport? _report;
    private DateTime? _periodFrom;
    private DateTime? _periodTo;
    private bool _includeSummary = true;
    private bool _includeTopBooks = true;
    private bool _includeOverdueReaders = true;
    private bool _includeGenreDistribution = true;
    private bool _writeIndented = true;
    private JsonNamingStyle _namingStyle = JsonNamingStyle.CamelCase;

    public ReportsViewModel(LibraryWorkspace workspace, ReportService reportService, IReportExporter exporter,
        IDialogService dialogs, ApplicationState state)
    {
        _workspace = workspace;
        _reportService = reportService;
        _exporter = exporter;
        _dialogs = dialogs;
        _state = state;
        BindBusyState(state);

        RefreshReportCommand = RegisterCommand(RefreshReport, () => !IsBusy);
        ExportReportCommand = RegisterAsyncCommand(ExportAsync, () => !IsBusy,
            exception => _dialogs.ShowError("Не удалось выгрузить отчёт", exception));

        _workspace.LoansChanged += (_, _) => RefreshReport();
        _workspace.Books.CollectionChanged += (_, _) => RefreshReport();
        _workspace.Readers.CollectionChanged += (_, _) => RefreshReport();

        RefreshReport();
    }

    public ObservableCollection<TopBookRow> TopBooks { get; } = new();
    public ObservableCollection<OverdueReaderRow> OverdueReaders { get; } = new();
    public ObservableCollection<GenreShareRow> GenreDistribution { get; } = new();

    public IReadOnlyList<JsonNamingStyle> NamingStyles { get; } = Enum.GetValues<JsonNamingStyle>();

    public LibrarySummary? Summary => _report?.Summary;
    public string ReportInfo => $"Отчёт построен: {_report?.GeneratedAt.ToString("dd.MM.yyyy HH:mm:ss") ?? "—"}";

    public DateTime? PeriodFrom { get => _periodFrom; set { if (SetProperty(ref _periodFrom, value)) RefreshReport(); } }
    public DateTime? PeriodTo { get => _periodTo; set { if (SetProperty(ref _periodTo, value)) RefreshReport(); } }

    public bool IncludeSummary { get => _includeSummary; set => SetProperty(ref _includeSummary, value); }
    public bool IncludeTopBooks { get => _includeTopBooks; set => SetProperty(ref _includeTopBooks, value); }
    public bool IncludeOverdueReaders { get => _includeOverdueReaders; set => SetProperty(ref _includeOverdueReaders, value); }
    public bool IncludeGenreDistribution { get => _includeGenreDistribution; set => SetProperty(ref _includeGenreDistribution, value); }
    public bool WriteIndented { get => _writeIndented; set => SetProperty(ref _writeIndented, value); }
    public JsonNamingStyle NamingStyle { get => _namingStyle; set => SetProperty(ref _namingStyle, value); }

    public RelayCommand RefreshReportCommand { get; }
    public AsyncRelayCommand ExportReportCommand { get; }

    public void RefreshReport()
    {
        _report = _reportService.Build(_workspace.Books.ToList(), _workspace.Readers.ToList(),
            _workspace.Loans.ToList(), PeriodFrom, PeriodTo);

        CollectionHelper.Replace(TopBooks, _report.TopBooks ?? Array.Empty<TopBookRow>());
        CollectionHelper.Replace(OverdueReaders, _report.OverdueReaders ?? Array.Empty<OverdueReaderRow>());
        CollectionHelper.Replace(GenreDistribution, _report.GenreDistribution ?? Array.Empty<GenreShareRow>());

        OnPropertyChanged(nameof(Summary));
        OnPropertyChanged(nameof(ReportInfo));
    }

    private async Task ExportAsync()
    {
        var path = _dialogs.ChooseJsonReportFile($"library-report-{DateTime.Now:yyyy-MM-dd_HH-mm}.json");
        if (path is null || _state.IsBusy) return;

        var token = _state.BeginOperation("Выгрузка отчёта в JSON...");
        var status = "Отчёт сохранён";
        try
        {
            RefreshReport();
            var options = new ReportExportOptions(WriteIndented, NamingStyle,
                IncludeSummary, IncludeTopBooks, IncludeOverdueReaders, IncludeGenreDistribution);

            await _exporter.ExportAsync(_report!, path, options, token);

            status = $"Отчёт выгружен: {Path.GetFileName(path)}";
            _dialogs.ShowInformation($"Отчёт сохранён в файл:{Environment.NewLine}{path}", "Экспорт отчёта");
        }
        catch (OperationCanceledException)
        {
            status = "Экспорт отчёта отменён";
        }
        catch (Exception ex)
        {
            status = "Ошибка экспорта отчёта";
            _dialogs.ShowError("Не удалось выгрузить отчёт", ex);
        }
        finally
        {
            _state.EndOperation(status);
        }
    }
}