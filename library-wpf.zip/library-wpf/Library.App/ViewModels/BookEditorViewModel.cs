using Library.App.Infrastructure;
using Library.App.Models;
using Library.App.Services;

namespace Library.App.ViewModels;

/// <summary>Форма книги: валидация через INotifyDataErrorInfo, невалидные данные не сохраняются.</summary>
public sealed class BookEditorViewModel : ValidatableViewModelBase
{
    private readonly IReadOnlyList<Book> _catalog;
    private readonly int _issuedCopies;
    private readonly string? _originalIsbn;
    private readonly bool _isIsbnLocked;

    private string _author = string.Empty;
    private string _title = string.Empty;
    private string _isbn = string.Empty;
    private string _genre = string.Empty;
    private string _yearText = DateTime.Today.Year.ToString();
    private string _copiesText = "1";

    public BookEditorViewModel(Book? source, IReadOnlyList<Book> catalog, int issuedCopies, bool isIsbnLocked)
    {
        _catalog = catalog;
        _issuedCopies = issuedCopies;
        _isIsbnLocked = isIsbnLocked;
        _originalIsbn = source?.Isbn;

        WindowTitle = source is null ? "Новая книга" : "Изменение книги";
        Genres = catalog.Select(book => book.Genre)
            .Where(genre => !string.IsNullOrWhiteSpace(genre))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(genre => genre, StringComparer.CurrentCulture)
            .ToList();

        if (source is not null)
        {
            _author = source.Author;
            _title = source.Title;
            _isbn = source.Isbn;
            _genre = source.Genre;
            _yearText = source.Year.ToString();
            _copiesText = source.TotalCopies.ToString();
        }

        AddValidator(nameof(Author), () => string.IsNullOrWhiteSpace(Author) ? "Укажите автора."
            : Author.Trim().Length < 2 ? "Слишком короткое имя автора." : null);
        AddValidator(nameof(Title), () => string.IsNullOrWhiteSpace(Title) ? "Укажите название книги." : null);
        AddValidator(nameof(Isbn), ValidateIsbn);
        AddValidator(nameof(Genre), () => string.IsNullOrWhiteSpace(Genre) ? "Укажите жанр." : null);
        AddValidator(nameof(YearText), () =>
            int.TryParse(YearText, out var year) && ValidationRules.IsYearValid(year)
                ? null : $"Год — целое число от 1400 до {DateTime.Today.Year + 1}.");
        AddValidator(nameof(CopiesText), ValidateCopies);

        AcceptCommand = RegisterCommand(Accept, () => !HasErrors);
        ValidateAll();
    }

    public string WindowTitle { get; }
    public IReadOnlyList<string> Genres { get; }
    public Book? Result { get; private set; }
    public RelayCommand AcceptCommand { get; }

    /// <summary>Запрос закрытия окна: true — данные приняты (обрабатывает слой Views).</summary>
    public event EventHandler<bool>? CloseRequested;

    public string Author { get => _author; set => SetProperty(ref _author, value); }
    public string Title { get => _title; set => SetProperty(ref _title, value); }
    public string Isbn { get => _isbn; set => SetProperty(ref _isbn, value); }
    public string Genre { get => _genre; set => SetProperty(ref _genre, value); }
    public string YearText { get => _yearText; set => SetProperty(ref _yearText, value); }
    public string CopiesText { get => _copiesText; set => SetProperty(ref _copiesText, value); }

    private string? ValidateIsbn()
    {
        if (string.IsNullOrWhiteSpace(Isbn)) return "Укажите ISBN.";
        if (!ValidationRules.IsIsbnFormatValid(Isbn))
            return "ISBN должен содержать 10 или 13 цифр (допустимы дефисы).";
        if (_isIsbnLocked && !string.Equals(Isbn.Trim(), _originalIsbn, StringComparison.OrdinalIgnoreCase))
            return "ISBN нельзя менять: по книге есть история выдач.";
        if (_catalog.Any(book => !string.Equals(book.Isbn, _originalIsbn, StringComparison.OrdinalIgnoreCase)
                              && string.Equals(book.Isbn.Trim(), Isbn.Trim(), StringComparison.OrdinalIgnoreCase)))
            return "Книга с таким ISBN уже есть в каталоге.";
        return null;
    }

    private string? ValidateCopies()
    {
        if (!int.TryParse(CopiesText, out var copies)) return "Количество экземпляров — целое число.";
        if (copies < 0) return "Количество экземпляров не может быть отрицательным.";
        if (copies < _issuedCopies) return $"Сейчас на руках {_issuedCopies} экз. — меньше указать нельзя.";
        return null;
    }

    private void Accept()
    {
        ValidateAll();
        if (HasErrors) return;

        Result = new Book
        {
            Author = Author.Trim(),
            Title = Title.Trim(),
            Isbn = Isbn.Trim(),
            Genre = Genre.Trim(),
            Year = int.Parse(YearText),
            TotalCopies = int.Parse(CopiesText)
        };

        CloseRequested?.Invoke(this, true);
    }
}