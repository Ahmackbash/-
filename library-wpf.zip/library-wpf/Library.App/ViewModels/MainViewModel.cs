using System.Collections.ObjectModel;
using Library.App.Infrastructure;
using Library.App.Services;

namespace Library.App.ViewModels;

/// <summary>Главная ViewModel: навигация между экранами, загрузка, сохранение, отмена.</summary>
public sealed class MainViewModel : ViewModelBase
{
    private readonly LibraryWorkspace _workspace;
    private readonly ApplicationState _state;
    private readonly IDialogService _dialogs;
    private ViewModelBase _currentViewModel;

    public MainViewModel(LibraryWorkspace workspace, ApplicationState state, IDialogService dialogs,
        CatalogViewModel catalog, ReadersViewModel readers, LoansViewModel loans, ReportsViewModel reports)
    {
        _workspace = workspace;
        _state = state;
        _dialogs = dialogs;

        Catalog = catalog;
        Readers = readers;
        Loans = loans;
        Reports = reports;
        _currentViewModel = catalog;

        BindBusyState(state);

        _state.PropertyChanged += (_, args) =>
        {
            if (args.PropertyName == nameof(ApplicationState.StatusMessage)) OnPropertyChanged(nameof(StatusMessage));
            if (args.PropertyName == nameof(ApplicationState.CanCancel)) OnPropertyChanged(nameof(CanCancel));
        };

        _workspace.PropertyChanged += (_, args) =>
        {
            if (args.PropertyName == nameof(LibraryWorkspace.HasPendingChanges))
            {
                OnPropertyChanged(nameof(HasPendingChanges));
                RefreshCommands();
            }
        };

        Sections.Add(new NavigationItemViewModel("Каталог книг", "catalog", Navigate, state));
        Sections.Add(new NavigationItemViewModel("Читатели", "readers", Navigate, state));
        Sections.Add(new NavigationItemViewModel("Выдачи и возвраты", "loans", Navigate, state));
        Sections.Add(new NavigationItemViewModel("Отчёты", "reports", Navigate, state));
        Sections[0].IsActive = true;

        LoadCommand = RegisterAsyncCommand(LoadAsync, () => !IsBusy,
            exception => _dialogs.ShowError("Не удалось загрузить данные", exception));
        SaveCommand = RegisterAsyncCommand(() => _workspace.SaveAsync(), () => !IsBusy,
            exception => _dialogs.ShowError("Не удалось сохранить данные", exception));
        CancelCommand = RegisterCommand(_state.CancelCurrentOperation, () => _state.CanCancel);
    }

    public CatalogViewModel Catalog { get; }
    public ReadersViewModel Readers { get; }
    public LoansViewModel Loans { get; }
    public ReportsViewModel Reports { get; }

    public ObservableCollection<NavigationItemViewModel> Sections { get; } = new();

    public ViewModelBase CurrentViewModel
    {
        get => _currentViewModel;
        private set => SetProperty(ref _currentViewModel, value);
    }

    public string StatusMessage => _state.StatusMessage;
    public bool CanCancel => _state.CanCancel;
    public bool HasPendingChanges => _workspace.HasPendingChanges;

    public AsyncRelayCommand LoadCommand { get; }
    public AsyncRelayCommand SaveCommand { get; }
    public RelayCommand CancelCommand { get; }

    public Task InitializeAsync() => LoadAsync();

    /// <summary>Вызывается при закрытии окна: true — можно закрывать.</summary>
    public async Task<bool> PrepareExitAsync()
    {
        if (!HasPendingChanges) return true;

        var answer = _dialogs.ConfirmSaveChanges();
        if (answer is null) return false;
        if (answer == false) return true;

        await _workspace.SaveAsync("Сохранение перед выходом...");
        return !HasPendingChanges; // при сбое сохранения окно остаётся открытым
    }

    private async Task LoadAsync()
    {
        await _workspace.LoadAsync();
        Reports.RefreshReport();
    }

    private void Navigate(string key)
    {
        CurrentViewModel = key switch
        {
            "readers" => Readers,
            "loans" => Loans,
            "reports" => Reports,
            _ => Catalog
        };

        foreach (var section in Sections) section.IsActive = section.Key == key;
    }
}