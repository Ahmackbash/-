using Library.App.Infrastructure;
using Library.App.Models;
using Library.App.Services;

namespace Library.App.ViewModels;

/// <summary>Строка каталога: книга + расчёт свободных экземпляров.</summary>
public sealed class BookRowViewModel : ViewModelBase
{
    private int _availableCopies;

    public BookRowViewModel(Book book) => Book = book;

    public Book Book { get; }
    public string Author => Book.Author;
    public string Title => Book.Title;
    public string Isbn => Book.Isbn;
    public int Year => Book.Year;
    public string Genre => Book.Genre;
    public int TotalCopies => Book.TotalCopies;

    public int AvailableCopies
    {
        get => _availableCopies;
        set
        {
            if (SetProperty(ref _availableCopies, value)) OnPropertyChanged(nameof(IsAvailable));
        }
    }

    public bool IsAvailable => AvailableCopies > 0;

    /// <summary>Фабрика строк: используется каталогом и формой выдачи (без дублирования).</summary>
    public static IEnumerable<BookRowViewModel> CreateRows(IEnumerable<Book> books, IReadOnlyCollection<Loan> loans,
        LoanService loanService)
        => books.Select(book => new BookRowViewModel(book)
        {
            AvailableCopies = loanService.GetAvailableCopies(book, loans)
        }).ToList();
}