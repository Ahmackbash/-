using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Data;
using Library.App.Infrastructure;
using Library.App.Models;
using Library.App.Services;

namespace Library.App.ViewModels;

/// <summary>Режимы фильтра списка выдач (порядок совпадает с пунктами ComboBox).</summary>
public enum LoanFilterMode
{
    All = 0,
    Active = 1,
    Overdue = 2,
    Returned = 3
}

/// <summary>Экран выдач и возвратов: расчёт просрочки и штрафа, CanExecute по бизнес-правилам.</summary>
public sealed class LoansViewModel : ValidatableViewModelBase
{
    private readonly LibraryWorkspace _workspace;
    private readonly LoanService _loanService;
    private readonly IDialogService _dialogs;
    private readonly ObservableCollection<LoanRowViewModel> _rows = new();

    // Собственные источники представлений: не зависят от других экранов и не умирают от сборщика мусора.
    private readonly CollectionViewSource _loansCvs = new();
    private readonly CollectionViewSource _readersCvs = new();

    private BookRowViewModel? _selectedBookOption;
    private Reader? _selectedReader;
    private DateTime? _issueDate = DateTime.Today;
    private string _termDaysText = LoanService.DefaultLoanTermDays.ToString();
    private LoanRowViewModel? _selectedRow;
    private DateTime? _returnDate = DateTime.Today;
    private int _filterIndex;
    private string _searchText = string.Empty;

    public LoansViewModel(LibraryWorkspace workspace, LoanService loanService, IDialogService dialogs, ApplicationState state)
    {
        _workspace = workspace;
        _loanService = loanService;
        _dialogs = dialogs;
        BindBusyState(state);

        _loansCvs.Source = _rows;
        LoansView = _loansCvs.View;
        LoansView.Filter = FilterRow;

        _readersCvs.Source = _workspace.Readers;
        ReadersView = _readersCvs.View;
        ReadersView.SortDescriptions.Add(new SortDescription(nameof(Reader.FullName), ListSortDirection.Ascending));

        AddValidator(nameof(SelectedBookOption), () => SelectedBookOption is null ? "Выберите книгу."
            : SelectedBookOption.AvailableCopies <= 0 ? "Свободных экземпляров нет." : null);
        AddValidator(nameof(SelectedReader), () => SelectedReader is null ? "Выберите читателя." : null);
        AddValidator(nameof(IssueDate), () => IssueDate is null ? "Укажите дату выдачи."
            : IssueDate.Value.Date > DateTime.Today ? "Дата выдачи не может быть в будущем." : null);
        AddValidator(nameof(TermDaysText), () => int.TryParse(TermDaysText, out var days) && days is > 0 and <= 365
            ? null : "Срок выдачи — целое число дней от 1 до 365.");
        AddValidator(nameof(ReturnDate), () => ReturnDate is null ? "Укажите дату возврата."
            : SelectedRow is not null && ReturnDate.Value.Date < SelectedRow.IssueDate.Date ? "Дата возврата раньше даты выдачи."
            : ReturnDate.Value.Date > DateTime.Today ? "Дата возврата не может быть в будущем." : null);

        IssueCommand = RegisterAsyncCommand(IssueAsync,
            () => !IsBusy && !HasErrorsFor(nameof(SelectedBookOption), nameof(SelectedReader), nameof(IssueDate), nameof(TermDaysText)),
            exception => _dialogs.ShowError("Не удалось оформить выдачу", exception));

        ReturnCommand = RegisterAsyncCommand(ReturnAsync,
            () => !IsBusy && SelectedRow is { IsActive: true } && !HasErrorsFor(nameof(ReturnDate)),
            exception => _dialogs.ShowError("Не удалось оформить возврат", exception));

        ValidateAll();
        RebuildBookOptions();
        RebuildRows();

        _workspace.Books.CollectionChanged += (_, _) => RebuildBookOptions();
        _workspace.Readers.CollectionChanged += (_, _) => { ReadersView.Refresh(); RebuildRows(); };
        _workspace.LoansChanged += (_, _) => { RebuildBookOptions(); RebuildRows(); };
    }

    public ICollectionView LoansView { get; private set; } = null!;
    public ICollectionView ReadersView { get; private set; } = null!;
    public ObservableCollection<BookRowViewModel> BookOptions { get; } = new();

    public BookRowViewModel? SelectedBookOption { get => _selectedBookOption; set => SetProperty(ref _selectedBookOption, value); }
    public Reader? SelectedReader { get => _selectedReader; set => SetProperty(ref _selectedReader, value); }

    public DateTime? IssueDate
    {
        get => _issueDate;
        set { if (SetProperty(ref _issueDate, value)) OnPropertyChanged(nameof(DueDatePreview)); }
    }

    public string TermDaysText
    {
        get => _termDaysText;
        set { if (SetProperty(ref _termDaysText, value)) OnPropertyChanged(nameof(DueDatePreview)); }
    }

    public DateTime? ReturnDate { get => _returnDate; set => SetProperty(ref _returnDate, value); }

    public LoanRowViewModel? SelectedRow
    {
        get => _selectedRow;
        set
        {
            if (!SetProperty(ref _selectedRow, value)) return;
            Revalidate(nameof(ReturnDate));
            OnPropertyChanged(nameof(SelectedLoanSummary));
            RefreshCommands();
        }
    }

    public int FilterIndex
    {
        get => _filterIndex;
        set { if (SetProperty(ref _filterIndex, value)) LoansView.Refresh(); }
    }

    public string SearchText
    {
        get => _searchText;
        set { if (SetProperty(ref _searchText, value)) LoansView.Refresh(); }
    }

    public string DueDatePreview => IssueDate is { } date && int.TryParse(TermDaysText, out var days) && days > 0
        ? date.AddDays(days).ToString("dd.MM.yyyy")
        : "—";

    public string SelectedLoanSummary => SelectedRow is null
        ? "Выдача не выбрана."
        : $"«{SelectedRow.BookTitle}» — {SelectedRow.ReaderName}; просрочка: {SelectedRow.OverdueDays} дн.; штраф: {SelectedRow.Fine:0.##} ед.";

    public AsyncRelayCommand IssueCommand { get; private set; } = null!;
    public AsyncRelayCommand ReturnCommand { get; private set; } = null!;

    private void RebuildBookOptions()
    {
        var selectedIsbn = SelectedBookOption?.Isbn;
        CollectionHelper.Replace(BookOptions,
            BookRowViewModel.CreateRows(_workspace.Books.ToList(), _workspace.Loans.ToList(), _loanService));
        SelectedBookOption = BookOptions.FirstOrDefault(row => row.Isbn == selectedIsbn);
    }

    private void RebuildRows()
    {
        var selectedId = SelectedRow?.Loan.Id;
        CollectionHelper.Replace(_rows, LoanRowViewModel.CreateRows(
            _workspace.Loans, _workspace.Books.ToList(), _workspace.Readers.ToList(), _loanService));

        SelectedRow = _rows.FirstOrDefault(row => row.Loan.Id == selectedId);
        LoansView.Refresh();
        OnPropertyChanged(nameof(SelectedLoanSummary));
        RefreshCommands();
    }

    private bool FilterRow(object item)
    {
        if (item is not LoanRowViewModel row) return false;

        var mode = (LoanFilterMode)FilterIndex;
        if (mode == LoanFilterMode.Active && !row.IsActive) return false;
        if (mode == LoanFilterMode.Overdue && !row.IsOverdue) return false;
        if (mode == LoanFilterMode.Returned && row.IsActive) return false;

        if (string.IsNullOrWhiteSpace(SearchText)) return true;

        var query = SearchText.Trim();
        return row.BookTitle.Contains(query, StringComparison.OrdinalIgnoreCase)
            || row.ReaderName.Contains(query, StringComparison.OrdinalIgnoreCase);
    }

    private async Task IssueAsync()
    {
        ValidateAll();
        if (HasErrorsFor(nameof(SelectedBookOption), nameof(SelectedReader), nameof(IssueDate), nameof(TermDaysText)))
        {
            _dialogs.ShowWarning("Проверьте данные выдачи.");
            return;
        }

        try
        {
            var loan = _loanService.CreateLoan(SelectedBookOption!.Book, SelectedReader!,
                IssueDate!.Value, int.Parse(TermDaysText), _workspace.Loans);

            _workspace.Loans.Add(loan);
            await _workspace.CommitAsync("Сохранение выдачи...");
        }
        catch (DomainException ex)
        {
            _dialogs.ShowWarning(ex.Message);
        }
    }

    private async Task ReturnAsync()
    {
        var row = SelectedRow;
        if (row is null) return;

        Revalidate(nameof(ReturnDate));
        if (ReturnDate is null || HasErrorsFor(nameof(ReturnDate)))
        {
            _dialogs.ShowWarning("Проверьте дату возврата.");
            return;
        }

        try
        {
            _loanService.Return(row.Loan, ReturnDate.Value);
            _workspace.NotifyLoansChanged();
            await _workspace.CommitAsync("Сохранение возврата...");
        }
        catch (DomainException ex)
        {
            _dialogs.ShowWarning(ex.Message);
        }
    }
}