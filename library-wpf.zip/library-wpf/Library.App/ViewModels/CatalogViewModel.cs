using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Data;
using Library.App.Infrastructure;
using Library.App.Models;
using Library.App.Services;

namespace Library.App.ViewModels;

/// <summary>Экран каталога: комбинированный поиск, фильтр по жанру и доступности, импорт CSV.</summary>
public sealed class CatalogViewModel : ViewModelBase
{
    private const string AllGenres = "Все жанры";

    private readonly LibraryWorkspace _workspace;
    private readonly LoanService _loanService;
    private readonly ICatalogImporter _importer;
    private readonly IDialogService _dialogs;
    private readonly AppPaths _paths;
    private readonly ApplicationState _state;
    private readonly ObservableCollection<BookRowViewModel> _rows = new();

    // Источник представления храним в поле: иначе сборщик мусора может убить представление.
    private readonly CollectionViewSource _booksCvs = new();

    private string _searchAuthor = string.Empty;
    private string _searchTitle = string.Empty;
    private string _searchIsbn = string.Empty;
    private string _selectedGenre = AllGenres;
    private bool _onlyAvailable;
    private BookRowViewModel? _selectedRow;

    public CatalogViewModel(LibraryWorkspace workspace, LoanService loanService, ICatalogImporter importer,
        IDialogService dialogs, AppPaths paths, ApplicationState state)
    {
        _workspace = workspace;
        _loanService = loanService;
        _importer = importer;
        _dialogs = dialogs;
        _paths = paths;
        _state = state;
        BindBusyState(state);

        _booksCvs.Source = _rows;
        BooksView = _booksCvs.View;
        BooksView.Filter = FilterRow;
        BooksView.SortDescriptions.Add(new SortDescription(nameof(BookRowViewModel.Title), ListSortDirection.Ascending));

        RefreshGenres();
        RebuildRows();

        _workspace.Books.CollectionChanged += (_, _) => { RefreshGenres(); RebuildRows(); };
        _workspace.LoansChanged += (_, _) => RebuildRows();

        AddBookCommand = RegisterAsyncCommand(AddBookAsync, () => !IsBusy, OnError);
        EditBookCommand = RegisterAsyncCommand(EditBookAsync, () => !IsBusy && SelectedRow is not null, OnError);
        DeleteBookCommand = RegisterAsyncCommand(DeleteBookAsync, () => !IsBusy && SelectedRow is not null, OnError);
        ImportCatalogCommand = RegisterAsyncCommand(ImportCatalogAsync, () => !IsBusy, OnError);
        ClearFiltersCommand = RegisterCommand(ClearFilters, () => !IsBusy);
    }

    public ICollectionView BooksView { get; private set; } = null!;
    public ObservableCollection<string> Genres { get; } = new() { AllGenres };

    public string SearchAuthor { get => _searchAuthor; set { if (SetProperty(ref _searchAuthor, value)) BooksView.Refresh(); } }
    public string SearchTitle { get => _searchTitle; set { if (SetProperty(ref _searchTitle, value)) BooksView.Refresh(); } }
    public string SearchIsbn { get => _searchIsbn; set { if (SetProperty(ref _searchIsbn, value)) BooksView.Refresh(); } }
    public string SelectedGenre { get => _selectedGenre; set { if (SetProperty(ref _selectedGenre, value)) BooksView.Refresh(); } }
    public bool OnlyAvailable { get => _onlyAvailable; set { if (SetProperty(ref _onlyAvailable, value)) BooksView.Refresh(); } }

    public BookRowViewModel? SelectedRow
    {
        get => _selectedRow;
        set { if (SetProperty(ref _selectedRow, value)) RefreshCommands(); }
    }

    public string CatalogSummary =>
        $"Книг: {_workspace.Books.Count}; экземпляров: {_workspace.Books.Sum(book => book.TotalCopies)}; свободно: {_rows.Sum(row => row.AvailableCopies)}";

    public AsyncRelayCommand AddBookCommand { get; private set; } = null!;
    public AsyncRelayCommand EditBookCommand { get; private set; } = null!;
    public AsyncRelayCommand DeleteBookCommand { get; private set; } = null!;
    public AsyncRelayCommand ImportCatalogCommand { get; private set; } = null!;
    public RelayCommand ClearFiltersCommand { get; private set; } = null!;

    private void OnError(Exception exception) => _dialogs.ShowError("Операция с каталогом не выполнена", exception);

    private void RebuildRows()
    {
        var selectedIsbn = SelectedRow?.Isbn;
        CollectionHelper.Replace(_rows,
            BookRowViewModel.CreateRows(_workspace.Books.ToList(), _workspace.Loans.ToList(), _loanService));

        SelectedRow = _rows.FirstOrDefault(row => row.Isbn == selectedIsbn);
        BooksView.Refresh();
        OnPropertyChanged(nameof(CatalogSummary));
        RefreshCommands();
    }

    private void RefreshGenres()
    {
        var current = SelectedGenre;
        var genres = _workspace.Books.Select(book => book.Genre)
            .Where(genre => !string.IsNullOrWhiteSpace(genre))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(genre => genre, StringComparer.CurrentCulture)
            .ToList();

        Genres.Clear();
        Genres.Add(AllGenres);
        foreach (var genre in genres) Genres.Add(genre);

        SelectedGenre = Genres.Contains(current) ? current : AllGenres;
    }

    /// <summary>Условия поиска комбинируются по «И».</summary>
    private bool FilterRow(object item)
    {
        if (item is not BookRowViewModel row) return false;

        if (!Matches(row.Author, SearchAuthor) || !Matches(row.Title, SearchTitle) || !Matches(row.Isbn, SearchIsbn))
            return false;
        if (SelectedGenre != AllGenres && !string.Equals(row.Genre, SelectedGenre, StringComparison.OrdinalIgnoreCase))
            return false;
        if (OnlyAvailable && !row.IsAvailable) return false;

        return true;
    }

    private static bool Matches(string value, string query)
        => string.IsNullOrWhiteSpace(query) || value.Contains(query.Trim(), StringComparison.OrdinalIgnoreCase);

    private void ClearFilters()
    {
        SearchAuthor = string.Empty;
        SearchTitle = string.Empty;
        SearchIsbn = string.Empty;
        SelectedGenre = AllGenres;
        OnlyAvailable = false;
    }

    private async Task AddBookAsync()
    {
        var created = _dialogs.EditBook(null, _workspace.Books.ToList(), 0, false);
        if (created is null) return;

        _workspace.Books.Add(created);
        await _workspace.CommitAsync("Сохранение каталога...");
    }

    private async Task EditBookAsync()
    {
        var row = SelectedRow;
        if (row is null) return;

        var issued = _loanService.GetActiveLoanCount(row.Isbn, _workspace.Loans);
        var isbnLocked = _workspace.Loans.Any(loan => loan.BookIsbn == row.Isbn);

        var edited = _dialogs.EditBook(row.Book, _workspace.Books.ToList(), issued, isbnLocked);
        if (edited is null) return;

        row.Book.CopyFrom(edited);
        RebuildRows();
        await _workspace.CommitAsync("Сохранение каталога...");
    }

    private async Task DeleteBookAsync()
    {
        var row = SelectedRow;
        if (row is null) return;

        if (_workspace.Loans.Any(loan => loan.BookIsbn == row.Isbn))
        {
            _dialogs.ShowWarning("По книге есть записи о выдачах. Удаление запрещено, чтобы сохранить историю.");
            return;
        }
        if (!_dialogs.Confirm($"Удалить книгу «{row.Title}»?")) return;

        _workspace.Books.Remove(row.Book);
        await _workspace.CommitAsync("Сохранение каталога...");
    }

    private async Task ImportCatalogAsync()
    {
        var path = _dialogs.ChooseCsvFile(_paths.SeedCatalogFile);
        if (path is null || _state.IsBusy) return;

        var token = _state.BeginOperation("Импорт каталога из CSV...");
        var status = "Импорт завершён";
        try
        {
            var result = await _importer.ImportAsync(path, token);
            int added = 0, updated = 0;

            foreach (var book in result.Books)
            {
                var existing = _workspace.Books.FirstOrDefault(item =>
                    string.Equals(item.Isbn, book.Isbn, StringComparison.OrdinalIgnoreCase));

                if (existing is null)
                {
                    _workspace.Books.Add(book);
                    added++;
                }
                else
                {
                    // Нельзя уменьшить фонд ниже числа выданных экземпляров.
                    var issued = _loanService.GetActiveLoanCount(existing.Isbn, _workspace.Loans);
                    book.TotalCopies = Math.Max(book.TotalCopies, issued);
                    existing.CopyFrom(book);
                    updated++;
                }
            }

            await _workspace.SaveWithinOperationAsync(token);
            RebuildRows();

            status = $"Импорт: добавлено {added}, обновлено {updated}, пропущено {result.Errors.Count}";
            if (result.Errors.Count > 0)
                _dialogs.ShowWarning(string.Join(Environment.NewLine, result.Errors.Take(20)), "Замечания импорта");
        }
        catch (OperationCanceledException)
        {
            status = "Импорт отменён";
        }
        catch (Exception ex)
        {
            status = "Ошибка импорта";
            _dialogs.ShowError("Не удалось импортировать каталог", ex);
        }
        finally
        {
            _state.EndOperation(status);
        }
    }
}