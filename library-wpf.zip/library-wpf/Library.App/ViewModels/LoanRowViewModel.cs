using Library.App.Infrastructure;
using Library.App.Models;
using Library.App.Services;

namespace Library.App.ViewModels;

/// <summary>Строка списка выдач: названия книги и читателя, просрочка и штраф.</summary>
public sealed class LoanRowViewModel : ViewModelBase
{
    public LoanRowViewModel(Loan loan, string bookTitle, string readerName, int overdueDays, decimal fine)
    {
        Loan = loan;
        BookTitle = bookTitle;
        ReaderName = readerName;
        OverdueDays = overdueDays;
        Fine = fine;
    }

    public Loan Loan { get; }
    public string BookTitle { get; }
    public string ReaderName { get; }
    public DateTime IssueDate => Loan.IssueDate;
    public DateTime DueDate => Loan.DueDate;
    public DateTime? ReturnDate => Loan.ReturnDate;
    public bool IsActive => !Loan.IsReturned;
    public int OverdueDays { get; }
    public decimal Fine { get; }
    public bool IsOverdue => OverdueDays > 0;

    public string StatusText => Loan.IsReturned
        ? (IsOverdue ? "Возвращена с просрочкой" : "Возвращена")
        : (IsOverdue ? "Просрочена" : "Выдана");

    public static IEnumerable<LoanRowViewModel> CreateRows(IEnumerable<Loan> loans, IReadOnlyCollection<Book> books,
        IReadOnlyCollection<Reader> readers, LoanService loanService)
    {
        var titles = books.GroupBy(book => book.Isbn, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First().Title, StringComparer.OrdinalIgnoreCase);
        var names = readers.GroupBy(reader => reader.TicketNumber, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First().FullName, StringComparer.OrdinalIgnoreCase);

        return loans
            .Select(loan => new LoanRowViewModel(
                loan,
                titles.TryGetValue(loan.BookIsbn, out var title) ? title : $"[книга {loan.BookIsbn}]",
                names.TryGetValue(loan.ReaderTicketNumber, out var name) ? name : $"[читатель {loan.ReaderTicketNumber}]",
                loanService.GetOverdueDays(loan),
                loanService.GetFine(loan)))
            .OrderByDescending(row => row.IssueDate)
            .ToList();
    }
}