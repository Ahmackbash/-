using Library.App.Infrastructure;
using Library.App.Models;
using Library.App.Services;

namespace Library.App.ViewModels;

/// <summary>Форма читателя с валидацией номера билета, ФИО, телефона и даты регистрации.</summary>
public sealed class ReaderEditorViewModel : ValidatableViewModelBase
{
    private readonly IReadOnlyList<Reader> _readers;
    private readonly string? _originalTicket;
    private readonly bool _isTicketLocked;

    private string _ticketNumber = string.Empty;
    private string _fullName = string.Empty;
    private string _phone = string.Empty;
    private DateTime? _registrationDate = DateTime.Today;

    public ReaderEditorViewModel(Reader? source, IReadOnlyList<Reader> readers, bool isTicketLocked)
    {
        _readers = readers;
        _isTicketLocked = isTicketLocked;
        _originalTicket = source?.TicketNumber;
        WindowTitle = source is null ? "Новый читатель" : "Изменение читателя";

        if (source is not null)
        {
            _ticketNumber = source.TicketNumber;
            _fullName = source.FullName;
            _phone = source.Phone;
            _registrationDate = source.RegistrationDate;
        }

        AddValidator(nameof(TicketNumber), ValidateTicket);
        AddValidator(nameof(FullName), () => string.IsNullOrWhiteSpace(FullName) ? "Укажите ФИО."
            : FullName.Trim().Length < 5 ? "ФИО слишком короткое." : null);
        AddValidator(nameof(Phone), () => ValidationRules.IsPhoneValid(Phone)
            ? null : "Телефон: 7–20 символов, цифры, пробелы, скобки, дефисы, необязательный '+'.");
        AddValidator(nameof(RegistrationDate), () => RegistrationDate is null ? "Укажите дату регистрации."
            : RegistrationDate.Value.Date > DateTime.Today ? "Дата регистрации не может быть в будущем."
            : RegistrationDate.Value.Year < 1900 ? "Слишком ранняя дата регистрации." : null);

        AcceptCommand = RegisterCommand(Accept, () => !HasErrors);
        ValidateAll();
    }

    public string WindowTitle { get; }
    public Reader? Result { get; private set; }
    public RelayCommand AcceptCommand { get; }

    public event EventHandler<bool>? CloseRequested;

    public string TicketNumber { get => _ticketNumber; set => SetProperty(ref _ticketNumber, value); }
    public string FullName { get => _fullName; set => SetProperty(ref _fullName, value); }
    public string Phone { get => _phone; set => SetProperty(ref _phone, value); }
    public DateTime? RegistrationDate { get => _registrationDate; set => SetProperty(ref _registrationDate, value); }

    private string? ValidateTicket()
    {
        if (!ValidationRules.IsTicketValid(TicketNumber))
            return "Номер билета: 3–20 символов (буквы, цифры, дефис).";
        if (_isTicketLocked && !string.Equals(TicketNumber.Trim(), _originalTicket, StringComparison.OrdinalIgnoreCase))
            return "Номер билета нельзя менять: по читателю есть история выдач.";
        if (_readers.Any(reader => !string.Equals(reader.TicketNumber, _originalTicket, StringComparison.OrdinalIgnoreCase)
                                && string.Equals(reader.TicketNumber.Trim(), TicketNumber.Trim(), StringComparison.OrdinalIgnoreCase)))
            return "Читатель с таким номером билета уже зарегистрирован.";
        return null;
    }

    private void Accept()
    {
        ValidateAll();
        if (HasErrors) return;

        Result = new Reader
        {
            TicketNumber = TicketNumber.Trim(),
            FullName = FullName.Trim(),
            Phone = Phone.Trim(),
            RegistrationDate = RegistrationDate!.Value.Date
        };

        CloseRequested?.Invoke(this, true);
    }
}