using Library.App.Infrastructure;

namespace Library.App.ViewModels;

/// <summary>Пункт навигации между экранами.</summary>
public sealed class NavigationItemViewModel : ViewModelBase
{
    private bool _isActive;

    public NavigationItemViewModel(string title, string key, Action<string> navigate, ApplicationState state)
    {
        Title = title;
        Key = key;
        BindBusyState(state);
        SelectCommand = RegisterCommand(() => navigate(key), () => !IsBusy);
    }

    public string Title { get; }
    public string Key { get; }
    public RelayCommand SelectCommand { get; }

    public bool IsActive { get => _isActive; set => SetProperty(ref _isActive, value); }
}