using System.ComponentModel;
using System.Windows.Data;
using Library.App.Infrastructure;
using Library.App.Models;
using Library.App.Services;

namespace Library.App.ViewModels;

/// <summary>Экран читателей: поиск, добавление, изменение, удаление с защитой истории выдач.</summary>
public sealed class ReadersViewModel : ViewModelBase
{
    private readonly LibraryWorkspace _workspace;
    private readonly IDialogService _dialogs;
    private readonly CollectionViewSource _readersCvs = new();
    private string _searchText = string.Empty;
    private Reader? _selectedReader;

    public ReadersViewModel(LibraryWorkspace workspace, IDialogService dialogs, ApplicationState state)
    {
        _workspace = workspace;
        _dialogs = dialogs;
        BindBusyState(state);

        _readersCvs.Source = _workspace.Readers;
        ReadersView = _readersCvs.View;
        ReadersView.Filter = FilterReader;
        ReadersView.SortDescriptions.Add(new SortDescription(nameof(Reader.FullName), ListSortDirection.Ascending));

        _workspace.Readers.CollectionChanged += (_, _) =>
        {
            ReadersView.Refresh();
            OnPropertyChanged(nameof(ReadersSummary));
            RefreshCommands();
        };

        AddReaderCommand = RegisterAsyncCommand(AddReaderAsync, () => !IsBusy, OnError);
        EditReaderCommand = RegisterAsyncCommand(EditReaderAsync, () => !IsBusy && SelectedReader is not null, OnError);
        DeleteReaderCommand = RegisterAsyncCommand(DeleteReaderAsync, () => !IsBusy && SelectedReader is not null, OnError);
        ClearSearchCommand = RegisterCommand(() => SearchText = string.Empty, () => !IsBusy);
    }

    public ICollectionView ReadersView { get; private set; } = null!;

    public string SearchText
    {
        get => _searchText;
        set { if (SetProperty(ref _searchText, value)) ReadersView.Refresh(); }
    }

    public Reader? SelectedReader
    {
        get => _selectedReader;
        set { if (SetProperty(ref _selectedReader, value)) RefreshCommands(); }
    }

    public string ReadersSummary => $"Читателей: {_workspace.Readers.Count}";

    public AsyncRelayCommand AddReaderCommand { get; private set; } = null!;
    public AsyncRelayCommand EditReaderCommand { get; private set; } = null!;
    public AsyncRelayCommand DeleteReaderCommand { get; private set; } = null!;
    public RelayCommand ClearSearchCommand { get; private set; } = null!;

    private void OnError(Exception exception) => _dialogs.ShowError("Операция со списком читателей не выполнена", exception);

    private bool FilterReader(object item)
    {
        if (item is not Reader reader) return false;
        if (string.IsNullOrWhiteSpace(SearchText)) return true;

        var query = SearchText.Trim();
        return reader.FullName.Contains(query, StringComparison.OrdinalIgnoreCase)
            || reader.TicketNumber.Contains(query, StringComparison.OrdinalIgnoreCase)
            || reader.Phone.Contains(query, StringComparison.OrdinalIgnoreCase);
    }

    private async Task AddReaderAsync()
    {
        var created = _dialogs.EditReader(null, _workspace.Readers.ToList(), false);
        if (created is null) return;

        _workspace.Readers.Add(created);
        await _workspace.CommitAsync("Сохранение читателей...");
    }

    private async Task EditReaderAsync()
    {
        var reader = SelectedReader;
        if (reader is null) return;

        var ticketLocked = _workspace.Loans.Any(loan => loan.ReaderTicketNumber == reader.TicketNumber);
        var edited = _dialogs.EditReader(reader, _workspace.Readers.ToList(), ticketLocked);
        if (edited is null) return;

        reader.CopyFrom(edited);
        ReadersView.Refresh();
        await _workspace.CommitAsync("Сохранение читателей...");
    }

    private async Task DeleteReaderAsync()
    {
        var reader = SelectedReader;
        if (reader is null) return;

        if (_workspace.Loans.Any(loan => loan.ReaderTicketNumber == reader.TicketNumber))
        {
            _dialogs.ShowWarning("По читателю есть записи о выдачах. Удаление запрещено, чтобы сохранить историю.");
            return;
        }
        if (!_dialogs.Confirm($"Удалить читателя «{reader.FullName}»?")) return;

        _workspace.Readers.Remove(reader);
        await _workspace.CommitAsync("Сохранение читателей...");
    }
}